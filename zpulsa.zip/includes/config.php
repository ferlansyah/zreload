<?php

/**
 * @package Script Pulsa Online
 * @version 1
 * @author Engky Datz* @link http://okepulsa.id
 * @link http://facebook.com/Engky09
 * @link http://okepulsa.id * @link https://www.bukalapak.com/engky09
 * @copyright 2015 -2016
 */

$MySQL = array(
    'host' => 'localhost', // MySQL Host
    'user' => 'root', // MySQL User
    'pass' => '', // MySQL Password
    'name' => 'db_zpulsa', // MySQL Database Name
    );

